
public class Income extends Atribut{
    
    
    
    public Income(String description, String date, int amount){
        super(description, date, amount);
        
    }
}
